function fn() {

var env = karate.env;
karate.log('karate ENV ==>',env);


var config = {
	baseURL: 'http://localhost:8080/',
	env:env
}

if(env == 'stage1')
{
	config.baseURL1 = 'https://gorest.co.in/public/v2/';
} 

else if(env == 'stage2')
{
	config.baseURL1 = 'https://gorest.co.in/public/v1/';
}

return config;
}