package feature_package;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.intuit.karate.Runner;


public class API_Test_Runner {
	

//	@BeforeAll
//	public static void before() {
//		System.setProperty("karate.env", "stage1");
//	}
//	
//	@Karate.Test
//	Karate testAPI() {
//		return Karate.run("POST_GOREST").tags("@post1").relativeTo(getClass());
//					}
	
	@Test
	public void testParallel() {
		Runner.path("file:src/test/java/feature_package/GET_API_DEMO.feature").tags("@get").parallel(2);
	}

}
