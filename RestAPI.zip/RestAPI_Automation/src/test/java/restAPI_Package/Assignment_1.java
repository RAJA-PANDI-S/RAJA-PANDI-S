package restAPI_Package;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Assignment_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Response response = RestAssured.get("https://reqres.in/api/users/3");
		
		String respbody = response.getBody().asPrettyString();
		System.out.print(respbody);

	}

}
