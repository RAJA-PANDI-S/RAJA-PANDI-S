package restAPI_Package;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Assignment_2 {
	@Test

	public void postRequest() {
		// TODO Auto-generated method stub
		JSONObject jsonObject = new JSONObject();
		
		jsonObject.put("name","Raja");
		jsonObject.put("job","Employee");

		RestAssured.baseURI = "https://reqres.in";
		RestAssured.given().body(jsonObject.toJSONString()).when().post("/api/users").then().statusCode(201).log().all();
		
		System.out.println(jsonObject.toString());

	}

}
