package restAPI_Package;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Assignment_5 {
	
	RequestSpecification reqSpec;
	ResponseSpecification respSpec;

	@BeforeClass
	public void setupSpec()
	{
		reqSpec = RestAssured.given().baseUri("https://restful-booker.herokuapp.com").basePath("/booking");
		respSpec = RestAssured.expect().statusLine("HTTP/1.1 200 OK").statusCode(200).contentType(ContentType.JSON); 
	}

	@Test
	public void getBookings()
	{
		Response resp = RestAssured.given(reqSpec, respSpec).get("/71");
		System.out.println(resp.asPrettyString());
		
	}
}
