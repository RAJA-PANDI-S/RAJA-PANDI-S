package restAPI_Package;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Assignment_4 {
	
@Test
	public void jsonPathValidator_Assert(){


		RestAssured.baseURI = "https://jsonplaceholder.typicode.com/users";
		RestAssured.given().when().get("/2").then().log().all();

		Response resp = RestAssured.given().when().get("/2");
		JsonPath jsonpath = resp.jsonPath();

		Assert.assertEquals(jsonpath.get("id"),2);
		Assert.assertEquals(jsonpath.get("address.zipcode"),"90566-7771");
		Assert.assertEquals(jsonpath.get("company.name"),"Deckow-Crist");

		System.out.println("ID : "+jsonpath.get("id"));
		System.out.println("Zipcode : "+jsonpath.get("address.zipcode"));
		System.out.println("Company : "+jsonpath.get("company.name"));

}
}
