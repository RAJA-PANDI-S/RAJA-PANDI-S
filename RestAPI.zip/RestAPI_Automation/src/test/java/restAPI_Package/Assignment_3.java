package restAPI_Package;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Assignment_3 {

	@Test
	public void jsonValidator_Extract(){

		RestAssured.baseURI = "https://reqres.in";
		RestAssured.given().when().get("/api/users?page=2").then().log().all();

		int page = RestAssured.given().when().get("/api/users?page=2").then().extract().path("per_page");

		System.out.println("Page # : "+page);
		}
}
