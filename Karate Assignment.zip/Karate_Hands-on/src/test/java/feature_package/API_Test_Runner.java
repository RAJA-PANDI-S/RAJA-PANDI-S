package feature_package;

import org.junit.jupiter.api.BeforeAll;

import com.intuit.karate.Runner;
import com.intuit.karate.junit5.Karate;
import com.intuit.karate.junit5.Karate.Test;

public class API_Test_Runner {
	

	@BeforeAll
	public static void before() {
		System.setProperty("karate.env", "stage1");
	}
	
	@Karate.Test
	Karate testAPI() {
		return Karate.run("POST_GOREST").tags("@post1").relativeTo(getClass());
					}
	
//	@Test
//	public void testParallel() {
//		Runner.path("file:src/test/java/feature_package/GET_API_DEMO.feature").tags("@get").parallel(2);
//	}

}
