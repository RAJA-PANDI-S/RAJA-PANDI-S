Create Table Country (CTRY_ID int primary key, CTRY_NAME varchar(25), CTRY_CAPITAL varchar(25), CTRY_POPULATION int, CTRY_STATES int, CTRY_LANGUAGE varchar(25), CTRY_SPORT varchar(25));
Insert into Country values (1, 'India', 'Delhi', 31000, 32, 'Tamil', 'Kabadi');
Insert into Country values (2, 'China', 'Beijing', 32000, 30, 'Chinese', 'Tennis');
