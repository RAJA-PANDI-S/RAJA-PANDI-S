package com.countryservice.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryServiceSpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
